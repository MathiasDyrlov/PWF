import os

folder_path = r"C:\Users\School\Danmarks Tekniske Universitet\Desktop\PWF_all components"

for filename in os.listdir(folder_path):
    file_path = os.path.join(folder_path, filename)
    if os.path.isfile(file_path):
        base, ext = os.path.splitext(filename)
        new_file_path = os.path.join(folder_path, base + ".txt")
        with open(file_path, 'rb') as f_in, open(new_file_path, 'wb') as f_out:
            f_out.write(f_in.read())
